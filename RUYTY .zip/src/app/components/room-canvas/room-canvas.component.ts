import { Component, Input, OnInit, ElementRef, ViewChild, OnChanges, SimpleChanges } from '@angular/core';
import { Room, Furniture, RoomColors } from '../../models/furniture.model';
import Konva from 'konva';

@Component({
  selector: 'app-room-canvas',
  template: `
    <div #container></div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 400px;
    }
  `]
})
export class RoomCanvasComponent implements OnInit, OnChanges {
  @Input() room: Room;
  @ViewChild('container', { static: true }) container: ElementRef;
  
  private stage: Konva.Stage;
  private layer: Konva.Layer;
  private backgroundImage: HTMLImageElement;

  ngOnInit() {
    this.initStage();
    this.drawRoom();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.room) {
      if (changes.room.currentValue.backgroundImage !== changes.room.previousValue?.backgroundImage) {
        this.loadBackgroundImage();
      } else {
        this.drawRoom();
      }
    }
  }

  private initStage() {
    this.stage = new Konva.Stage({
      container: this.container.nativeElement,
      width: this.room.width,
      height: this.room.height
    });
    this.layer = new Konva.Layer();
    this.stage.add(this.layer);
  }

  private loadBackgroundImage() {
    if (this.room.backgroundImage) {
      const image = new Image();
      image.onload = () => {
        this.backgroundImage = image;
        this.drawRoom();
      };
      image.src = this.room.backgroundImage;
    } else {
      this.backgroundImage = null;
      this.drawRoom();
    }
  }

  private drawRoom() {
    if (!this.layer) return;
    
    this.layer.destroyChildren();

    // Draw background
    if (this.backgroundImage) {
      const background = new Konva.Image({
        image: this.backgroundImage,
        width: this.room.width,
        height: this.room.height
      });
      this.layer.add(background);
    } else {
      const room = new Konva.Rect({
        width: this.room.width,
        height: this.room.height,
        fill: RoomColors[this.room.type],
        stroke: '#000',
        strokeWidth: 2
      });
      this.layer.add(room);
    }

    // Draw furniture
    this.room.furniture.forEach(item => {
      const furniture = new Konva.Rect({
        x: item.x,
        y: item.y,
        width: item.width,
        height: item.height,
        fill: item.color,
        stroke: '#000',
        strokeWidth: 1
      });
      
      const label = new Konva.Text({
        x: item.x,
        y: item.y + item.height / 2,
        text: item.type,
        fontSize: 12,
        fill: '#fff',
        padding: 2
      });

      this.layer.add(furniture);
      this.layer.add(label);
    });

    this.layer.draw();
  }
}