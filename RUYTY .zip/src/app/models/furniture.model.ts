export interface Furniture {
  id: string;
  type: string;
  width: number;
  height: number;
  x: number;
  y: number;
  color: string;
}

export interface Room {
  width: number;
  height: number;
  furniture: Furniture[];
  backgroundImage?: string;
  type: RoomType;
}

export enum RoomType {
  BEDROOM = 'bedroom',
  LIVING_ROOM = 'living_room',
  KITCHEN = 'kitchen',
  OFFICE = 'office',
  CUSTOM = 'custom'
}

export const RoomColors = {
  [RoomType.BEDROOM]: '#E6F3FF',
  [RoomType.LIVING_ROOM]: '#FFF2E6',
  [RoomType.KITCHEN]: '#E6FFE6',
  [RoomType.OFFICE]: '#FFE6E6',
  [RoomType.CUSTOM]: '#FFFFFF'
};

export const FurnitureColors = {
  bed: '#4A90E2',
  desk: '#F5A623',
  chair: '#7ED321',
  wardrobe: '#9013FE'
};