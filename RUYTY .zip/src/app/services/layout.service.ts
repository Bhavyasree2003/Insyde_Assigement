import { Injectable } from '@angular/core';
import { Room, Furniture } from '../models/furniture.model';

@Injectable({
  providedIn: 'root'
})
export class LayoutService {
  private readonly FURNITURE_TYPES = {
    bed: { width: 200, height: 150 },
    desk: { width: 120, height: 60 },
    chair: { width: 50, height: 50 },
    wardrobe: { width: 100, height: 60 }
  };

  generateLayout(room: Room): Room {
    // Simple layout algorithm
    const layout = { ...room, furniture: [] };
    let currentX = 20;
    let currentY = 20;

    room.furniture.forEach((item, index) => {
      const dimensions = this.FURNITURE_TYPES[item.type];
      
      // Basic collision avoidance
      if (currentX + dimensions.width > room.width) {
        currentX = 20;
        currentY += 100;
      }

      layout.furniture.push({
        ...item,
        width: dimensions.width,
        height: dimensions.height,
        x: currentX,
        y: currentY
      });

      currentX += dimensions.width + 20;
    });

    return layout;
  }

  validateLayout(room: Room): boolean {
    // Check if furniture fits within room
    return room.furniture.every(item => 
      item.x >= 0 && 
      item.y >= 0 && 
      item.x + item.width <= room.width && 
      item.y + item.height <= room.height
    );
  }
}