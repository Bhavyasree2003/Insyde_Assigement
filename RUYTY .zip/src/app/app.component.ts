import { Component, OnInit } from '@angular/core';
import { Room, Furniture, RoomType, RoomColors, FurnitureColors } from './models/furniture.model';
import { LayoutService } from './services/layout.service';

@Component({
  selector: 'my-app',
  template: `
    <div class="container">
      <h1>Furniture Layout Bot</h1>
      
      <div class="room-setup">
        <h3>Room Setup</h3>
        <div class="room-type-selector">
          <label>Room Type:</label>
          <select [(ngModel)]="selectedRoomType" (change)="updateRoomType()">
            <option [value]="RoomType.BEDROOM">Bedroom</option>
            <option [value]="RoomType.LIVING_ROOM">Living Room</option>
            <option [value]="RoomType.KITCHEN">Kitchen</option>
            <option [value]="RoomType.OFFICE">Office</option>
            <option [value]="RoomType.CUSTOM">Custom</option>
          </select>
        </div>

        <div class="image-upload">
          <label>Upload Room Image:</label>
          <input type="file" (change)="onImageUpload($event)" accept="image/*">
        </div>
      </div>

      <div class="controls">
        <button (click)="addFurniture('bed')" [disabled]="!canAddFurniture('bed')">Add Bed</button>
        <button (click)="addFurniture('desk')">Add Desk</button>
        <button (click)="addFurniture('chair')">Add Chair</button>
        <button (click)="addFurniture('wardrobe')">Add Wardrobe</button>
        <button (click)="generateLayout()">Generate Layout</button>
      </div>

      <div class="room-container">
        <app-room-canvas [room]="room"></app-room-canvas>
      </div>

      <div class="furniture-list">
        <h3>Current Furniture:</h3>
        <ul>
          <li *ngFor="let item of room.furniture">
            <span [style.backgroundColor]="item.color" class="color-dot"></span>
            {{ item.type }}
            <button (click)="removeFurniture(item.id)">Remove</button>
          </li>
        </ul>
      </div>
    </div>
  `,
  styles: [`
    .container {
      padding: 20px;
      max-width: 800px;
      margin: 0 auto;
    }
    .room-setup {
      margin-bottom: 20px;
      padding: 15px;
      background-color: #f5f5f5;
      border-radius: 4px;
    }
    .room-type-selector, .image-upload {
      margin-bottom: 10px;
    }
    .controls {
      margin-bottom: 20px;
    }
    button {
      margin-right: 10px;
      padding: 8px 16px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    button:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
    button:hover:not(:disabled) {
      background-color: #45a049;
    }
    .room-container {
      border: 1px solid #ccc;
      margin-bottom: 20px;
    }
    .furniture-list {
      background-color: #f5f5f5;
      padding: 15px;
      border-radius: 4px;
    }
    ul {
      list-style-type: none;
      padding: 0;
    }
    li {
      margin-bottom: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .color-dot {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      display: inline-block;
      margin-right: 8px;
    }
    select {
      padding: 8px;
      border-radius: 4px;
      border: 1px solid #ccc;
      margin-left: 10px;
    }
  `]
})
export class AppComponent implements OnInit {
  room: Room = {
    width: 400,
    height: 300,
    furniture: [],
    type: RoomType.BEDROOM
  };

  RoomType = RoomType;
  selectedRoomType = RoomType.BEDROOM;

  constructor(private layoutService: LayoutService) {}

  ngOnInit() {
    this.updateRoomType();
  }

  updateRoomType() {
    this.room = {
      ...this.room,
      type: this.selectedRoomType,
      furniture: []
    };
  }

  onImageUpload(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.room = {
          ...this.room,
          backgroundImage: e.target?.result as string
        };
      };
      reader.readAsDataURL(file);
    }
  }

  addFurniture(type: string) {
    const furniture: Furniture = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      width: 0,
      height: 0,
      x: 0,
      y: 0,
      color: FurnitureColors[type]
    };
    this.room.furniture.push(furniture);
  }

  removeFurniture(id: string) {
    this.room.furniture = this.room.furniture.filter(item => item.id !== id);
  }

  generateLayout() {
    this.room = this.layoutService.generateLayout(this.room);
  }

  canAddFurniture(type: string): boolean {
    if (type === 'bed' && this.selectedRoomType !== RoomType.BEDROOM) {
      return false;
    }
    return true;
  }
}